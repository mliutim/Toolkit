#!/bin/bash
echo "hello, PowerKey"
