#!/usr/bin/python

print('''udemy-dl can now be installed using pip

pip install udemy-dl


If you are looking for the old script, it is now located here:

src/udemy_dl/udemy_dl.py
''')
