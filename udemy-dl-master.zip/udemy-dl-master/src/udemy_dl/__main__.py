#!/usr/bin/env python
from __future__ import unicode_literals
from __future__ import print_function

if __name__ == '__main__':
    from .udemy_dl import main
    main()
